import requests
import time
import datetime

BOT_TOKEN = "8202969495:AAGf1TIJH_kvY0Navr3GcUJfM3b46sOhpSw"
CHAT_ID = 5659915827  # your Telegram user ID
PRICE_DIFF_THRESHOLD = 4  # 4% threshold
CHECK_INTERVAL = 60  # check every 60 seconds

BASE_URL = f"https://api.telegram.org/bot{BOT_TOKEN}"

def send_telegram_message(message):
    url = f"{BASE_URL}/sendMessage"
    try:
        requests.post(url, data={
            "chat_id": CHAT_ID,
            "text": message,
            "parse_mode": "Markdown"
        }, timeout=10)
    except:
        print("⚠️ Telegram send error")

def safe_request(url):
    for _ in range(3):
        try:
            r = requests.get(url, timeout=10)
            r.raise_for_status()
            return r.json()
        except:
            time.sleep(5)
    return None

def get_binance_prices():
    return safe_request("https://api.binance.com/api/v3/ticker/price") or []

def get_bitvavo_markets():
    return safe_request("https://api.bitvavo.com/v2/markets") or []

def get_bitvavo_price(market):
    data = safe_request(f"https://api.bitvavo.com/v2/ticker/price?market={market}")
    if data and "price" in data:
        try:
            return float(data["price"])
        except:
            return 0
    return 0

def get_eur_usd_from_binance(binance_dict):
    try:
        btc_usdt = binance_dict.get("BTCUSDT")
        btc_eur = binance_dict.get("BTCEUR")
        if btc_usdt and btc_eur:
            return btc_usdt / btc_eur
    except:
        pass
    return 1.09

def get_updates(offset=None):
    url = f"{BASE_URL}/getUpdates"
    params = {"timeout": 100}
    if offset:
        params["offset"] = offset
    try:
        resp = requests.get(url, params=params, timeout=120)
        resp.raise_for_status()
        return resp.json()
    except:
        return None

def reply_to_test_messages(last_update_id):
    updates = get_updates(last_update_id)
    if not updates or "result" not in updates:
        return last_update_id

    for item in updates["result"]:
        update_id = item["update_id"]
        message = item.get("message")
        if not message:
            continue
        text = message.get("text")
        chat_id = message["chat"]["id"]

        if text and text.lower() == "test" and chat_id == CHAT_ID:
            send_telegram_message("all good, all is working")
            print("✅ Replied to test message.")

        last_update_id = max(last_update_id or 0, update_id + 1)
    return last_update_id

def check_arbitrage():
    binance_prices = get_binance_prices()
    bitvavo_markets = get_bitvavo_markets()

    if not binance_prices or not bitvavo_markets:
        print("⚠️ API failed. Retrying in 10s...")
        send_telegram_message("⚠️ API fetch failed. Retrying...")
        time.sleep(10)
        return

    binance_dict = {i["symbol"]: float(i["price"]) for i in binance_prices}
    eur_usd = get_eur_usd_from_binance(binance_dict)
    print(f"📊 EUR/USD (from Binance): {eur_usd:.4f}")

    alerts = []

    for market in bitvavo_markets:
        symbol = market["market"]
        if not symbol.endswith("-eur"):
            continue

        base = symbol.split("-")[0].upper()
        binance_symbol = base + "USDT"

        if binance_symbol not in binance_dict:
            continue

        bitvavo_price = get_bitvavo_price(symbol)
        if bitvavo_price == 0:
            continue

        binance_price_eur = binance_dict[binance_symbol] / eur_usd
        diff_percent = (bitvavo_price - binance_price_eur) / binance_price_eur * 100

        if diff_percent >= PRICE_DIFF_THRESHOLD:
            alerts.append(
                f"💰 {symbol}  📈 *{diff_percent:.2f}%*\n"
                f"🟢 Buy on Binance: €{binance_price_eur:.4f}\n"
                f"🔴 Sell on Bitvavo: €{bitvavo_price:.4f}"
            )

    if alerts:
        final_msg = "🚨🔥 *Arbitrage Opportunity!*\n\n" + "\n\n".join(alerts)
        print(final_msg)
        send_telegram_message(final_msg)
    else:
        print("No arbitrage opportunities found.")

def is_allowed_time():
    hour = datetime.datetime.now().hour
    return 7 <= hour < 24

def main():
    print("🚀 Bot started. Will run only between 07:00 and 23:59")
    last_update_id = None

    while True:
        if is_allowed_time():
            last_update_id = reply_to_test_messages(last_update_id)
            check_arbitrage()
            time.sleep(CHECK_INTERVAL)
        else:
            print("⏸ Outside active hours (12 AM - 7 AM). Sleeping 10 min.")
            time.sleep(600)

if __name__ == "__main__":
    main()
